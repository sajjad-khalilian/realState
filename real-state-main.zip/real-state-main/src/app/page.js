import HomePage from "@/template/HomePage";

export default function Home() {
  return <HomePage />;
}

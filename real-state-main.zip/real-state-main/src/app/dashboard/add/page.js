import AddProfilePage from "@/template/AddProfilePage";

function AddProfile() {
  return <AddProfilePage />;
}

export default AddProfile;
